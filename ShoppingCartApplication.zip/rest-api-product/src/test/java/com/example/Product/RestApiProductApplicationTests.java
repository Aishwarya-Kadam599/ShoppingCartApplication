package com.example.Product;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
